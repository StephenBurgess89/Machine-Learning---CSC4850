ProjectQuestion1Part1.jar
	- Handles the missing values in the training and testing data sets using knn and taking the mean 
	attribute value to fill in the missing data.
	- Fixed data sets are stored in the input folder as NewTrainData1.., etc..
	
ProjectQuestionPart2.jar
	-implements the knn algorithm to derive a classification label for the testing data
	-the labels from the decision set are weighted baseed on euclidean distance to choose the most 		apropriate classification label for the test instance.
	-testing data labels are stored in separate files in the output folder
	
ProjectQuestion2.jar
	- implements knn to fill in all the missing data from the microarray data sets
	- The fixed data sets are stored in the output folder

All java files with source code can be found in the src folder.
